<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Surjo Sports | Platinum Edition</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;900&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary: #ff4757;
            --dark: #2f3542;
            --glass: rgba(255, 255, 255, 0.8);
            /* Multi-color spectrum for border animation */
            --rainbow: linear-gradient(270deg, #ff9a9e, #fad0c4, #fbc2eb, #8b00ff);
        }

        body {
            background-color: #f0f2f5;
            font-family: 'Poppins', sans-serif;
            color: var(--dark);
            overflow-x: hidden;
        }

        /* --- CAROUSEL & BLOG SECTION --- */
        .animated-border-box {
            position: relative;
            padding: 8px;
            background: linear-gradient(270deg, #ff9a9e, #fad0c4, #fbc2eb);
            background-size: 400% 400%;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        .carousel-img {
            height: 500px;
            width: 100%;
            object-fit: contain;
            background: #fff;
        }

        .old-price {
            text-decoration: line-through;
            color: #888;
            font-size: 1.2rem;
        }

        .new-price {
            color: var(--primary);
            font-weight: 900;
            font-size: 2.2rem;
        }

        /* --- ORDER PROCESS STEPS --- */
        .step-card {
            background: white;
            border-radius: 20px;
            padding: 25px;
            transition: 0.3s;
            border: 1px solid #eee;
        }

        .step-icon {
            font-size: 2.5rem;
            margin-bottom: 15px;
            display: block;
        }

        /* --- FLAG GRID --- */
        #team-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }

        @media (min-width: 992px) {
            #team-grid {
                grid-template-columns: repeat(4, 1fr);
            }
        }

        .flag-card {
            background: #fff;
            border-radius: 20px;
            padding: 10px;
            cursor: pointer;
            transition: 0.4s;
            border: 2px solid transparent;
            box-shadow: 10px 10px 20px #bebebe, -10px -10px 20px #ffffff;
        }

        .flag-card:not(.active) {
            opacity: 0.7;
            filter: grayscale(40%);
        }

        .flag-card.active {
            opacity: 1;
            filter: grayscale(0%);
            border-color: var(--primary);
            transform: scale(1.05);
            background: #fff5f6;
        }

        .flag-img {
            width: 100%;
            aspect-ratio: 3/2;
            object-fit: cover;
            border-radius: 15px;
        }

        /* --- PRODUCT CARDS (WIDE & ANIMATED) --- */
        .product-drawer {
            grid-column: 1 / -1;
            display: none;
            background: var(--glass);
            backdrop-filter: blur(10px);
            border-radius: 25px;
            padding: 30px;
            margin: 20px 0;
        }

        .product-card {
            position: relative;
            background: #fff;
            border-radius: 20px;
            padding: 4px;
            overflow: hidden;
            height: 100%;
            z-index: 1;
        }

        .product-card::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: var(--rainbow);
            animation: rotate_border 6s linear infinite;
            z-index: -1;
        }

        .product-card:hover::before {
            animation-duration: 2s;
            filter: blur(2px);
        }

        .product-inner {
            background: #fff;
            border-radius: 17px;
            padding: 20px;
            height: 100%;
        }

        @keyframes rotate_border {
            100% {
                transform: rotate(360deg);
            }
        }

        /* --- SIZE SELECTOR --- */
        .size-selector {
            display: flex;
            gap: 8px;
            margin: 15px 0;
            justify-content: center;
        }

        .size-label {
            width: 40px;
            height: 40px;
            border: 2px solid #eee;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            cursor: pointer;
            transition: 0.2s;
        }

        .size-radio:checked+.size-label {
            background: var(--dark);
            color: white;
            border-color: var(--dark);
        }

        .btn-add-cart {
            background: var(--primary);
            color: white;
            border: none;
            width: 100%;
            padding: 12px;
            border-radius: 12px;
            font-weight: 700;
            transition: 0.3s;
        }

        .btn-add-cart:hover {
            background: var(--dark);
            transform: scale(1.02);
        }

        .checkout-box {
            background: #fff;
            border-radius: 25px;
            padding: 40px;
            box-shadow: 20px 20px 60px #bebebe, -20px -20px 60px #ffffff;
        }
    </style>
</head>

<body>

    <div class="container py-5">
        <div class="text-center mb-5">
            <h1 style="font-weight: 900; font-size: 3rem;">SURJO <span style="color:var(--primary)">SPORTS</span></h1>
            <p class="text-muted">Premium Football Kits & Authentic Gear</p>
        </div>

        <div id="blog_div" class="mb-5"></div>

        <div id="oder_process" class="mb-5">
            <div class="row g-4 text-center">
                <div class="col-md-4">
                    <div class="step-card shadow-sm">
                        <span class="step-icon">👕</span>
                        <h5 class="fw-bold">1. পছন্দের জার্সি খুঁজুন</h5>
                        <p class="small text-muted mb-0">টিম সিলেক্ট করে আপনার জার্সিটি বাছাই করুন।</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="step-card shadow-sm">
                        <span class="step-icon">📏</span>
                        <h5 class="fw-bold">2. সঠিক সাইজ দিন</h5>
                        <p class="small text-muted mb-0">আপনার সঠিক মাপ (S-XXL) সিলেক্ট করে কার্টে যোগ করুন।</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="step-card shadow-sm">
                        <span class="step-icon">✅</span>
                        <h5 class="fw-bold">3. অর্ডার কনফার্ম করুন</h5>
                        <p class="small text-muted mb-0">আপনার ঠিকানা দিয়ে ক্যাশ অন ডেলিভারিতে অর্ডার করুন।</p>
                    </div>
                </div>
            </div>
        </div>

        <h2 class="fw-bold mb-4">পছন্দের টিমের জার্সি খুঁজে নিন</h2>
        <div id="team-grid" class="mb-5"></div>

        {{-- // --}}
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="checkout-box">
                    <h3 class="fw-bold mb-4">🛒 আপনার অর্ডার তালিকা</h3>
                    <div id="cart-list">
                        <p class="text-muted text-center">এখনো কোনো পণ্য যোগ করা হয়নি।</p>
                    </div>

                    <div class="d-flex justify-content-between h4 fw-bold mt-4 p-3 bg-light rounded-4">
                        <span>মোট খরচ:</span>
                        <span style="color:var(--primary)"><span id="total-val">0</span> টাকা</span>
                    </div>

                    <form id="order-form" class="mt-5">
                        <h5 class="fw-bold mb-3">ডেলিভারি তথ্য দিন</h5>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <input type="text" name="customer_name" class="form-control py-3 rounded-4"
                                    placeholder="আপনার নাম লিখুন">
                            </div>
                            <div class="col-md-6">
                                <input type="tel" name="mobile" class="form-control py-3 rounded-4"
                                    placeholder="মোবাইল নম্বর লিখুন" required>
                            </div>
                            <div class="col-12">
                                <textarea name="address" class="form-control py-3 rounded-4" rows="3"
                                    placeholder="আপনার বিস্তারিত ঠিকানা লিখুন (বাসা নং, রোড, এলাকা...)"></textarea>
                            </div>

                            <div class="col-12">
                                <div class="form-check p-3 rounded-4 border w-100 mb-2 bg-light">
                                    <input class="form-check-input ms-1" type="radio" name="area" id="in"
                                        value="60" onchange="updateTotal()" checked>
                                    <label class="form-check-label ms-2" for="in">ঢাকার ভিতরে (৬০ টাকা)</label>
                                </div>
                                <div class="form-check p-3 rounded-4 border w-100 bg-light">
                                    <input class="form-check-input ms-1" type="radio" name="area" id="out"
                                        value="120" onchange="updateTotal()">
                                    <label class="form-check-label ms-2" for="out">ঢাকার বাইরে (১২০ টাকা)</label>
                                </div>
                            </div>

                            <div class="col-12">
                                <button type="submit" class="btn btn-add-cart py-3 mt-3 w-100">
                                    অর্ডার নিশ্চিত করুন (ক্যাশ অন ডেলিভারি)
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        {{-- // --}}




    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        let cart = [];
        // We will populate this from the database
        let teams = [];

        // --- NEW: FETCH DYNAMIC TEAMS FROM LARAVEL API ---
        async function loadDynamicTeams() {
            try {
                const response = await fetch('/v1/categories/with_product');
                if (!response.ok) throw new Error("Network response was not ok");

                // Assign the API data to our global teams variable
                teams = await response.json();

                // Re-render the flags once the data is ready
                renderFlags();
            } catch (error) {
                console.error("Error fetching teams and products:", error);
                document.getElementById('team-grid').innerHTML = `
                <div class="col-12 text-center text-danger py-5">
                    Failed to load products. Please refresh the page.
                </div>`;
            }
        }

        async function renderHeroDeals() {
            try {
                const response = await fetch('/v1/blogs'); // Replace with actual URL
                const data = await response.json();
                const blogs = Array.isArray(data) ? data : (data.blogs || []);
                const container = document.getElementById('blog_div');

                console.log(response);

                if (blogs.length > 0) {
                    container.innerHTML = blogs.map((p, idx) => `
                    <div class="row align-items-center mb-5">
                        <div class="col-lg-6">
                            <div class="animated-border-box">
                                <div id="carousel-${p.id}" class="carousel slide" data-bs-ride="carousel" data-bs-interval="2000">
                                    <div class="carousel-inner">
                                        ${(p.images || [p.image]).map((img, i) => `
                                                                            <div class="carousel-item ${i === 0 ? 'active' : ''}">
                                                                                <img src="${img}" class="carousel-img rounded-3">
                                                                            </div>
                                                                        `).join('')}
                                    </div>
                                    <button class="carousel-control-prev" data-bs-target="#carousel-${p.id}" data-bs-slide="prev">
                                        <span class="carousel-control-prev-icon bg-dark rounded-circle"></span>
                                    </button>
                                    <button class="carousel-control-next" data-bs-target="#carousel-${p.id}" data-bs-slide="next">
                                        <span class="carousel-control-next-icon bg-dark rounded-circle"></span>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 px-lg-5 text-center text-lg-start mt-4 mt-lg-0">
                            <h1 class="display-4 fw-bold">${p.title}</h1>
                            <div class="my-3">
                                <span class="old-price">${p.regular_price} TK</span><br>
                                <span class="new-price">${p.offer_price} TK</span>
                            </div>
                            <p class="text-muted lead">${p.short_description || ''}</p>
                           <button class="btn btn-dark btn-lg px-5 rounded-pill" 
                                    onclick="document.getElementById('team-grid').scrollIntoView({behavior: 'smooth'}); toggleDrawer('${p.slug}')">
                                অর্ডার করতে চাই
                            </button>
                        </div>
                    </div>
                `).join('');
                }
            } catch (e) {
                console.log("Blog error:", e);
            }
        }

        function renderFlags() {
            const grid = document.getElementById('team-grid');

            if (teams.length === 0) {
                grid.innerHTML = '<p class="text-center">Loading teams...</p>';
                return;
            }

            grid.innerHTML = teams.map(t => `
            <div class="flag-card" id="flag-${t.id}" onclick="toggleDrawer('${t.id}')">
                <img src="${t.flag}" class="flag-img" onerror="this.src='https://placehold.co/300x200?text=Flag+Missing'">
                <div class="fw-bold mt-2 text-center">${t.name}</div>
            </div>
            <div class="product-drawer" id="drawer-${t.id}">
                <div class="d-flex justify-content-between mb-4">
                    <h4 class="fw-bold m-0">${t.name} KITS</h4>
                    <button class="btn-close" onclick="closeAll()"></button>
                </div>
                <div class="row row-cols-1 row-cols-lg-3 g-4">
                    ${t.kits.map(k => `
                                <div class="col">
                                    <div class="product-card">
                                    <div class="product-inner">
                                        <a href="v1/product/${k.slug}" class="text-decoration-none">
                                            <img src="${k.img}" class="w-100 rounded-3 mb-3 hover-zoom" 
                                                onerror="this.src='https://placehold.co/500x500?text=Product+Image'">
                                        </a>
                                        
                                        <a href="v1/product/${k.slug}" class="text-decoration-none">
                                            <h6 class="fw-bold text-dark mb-1">${k.name}</h6>
                                        </a>

                                        <div class="text-danger fw-bold h5">${k.price} TK</div>
                                        
                                        <div class="size-selector">
                                            ${['S','M','L','XL','XXL'].map(s => `
                                        <input type="radio" name="size-${k.id}" value="${s}" id="s-${k.id}-${s}" class="size-radio d-none">
                                        <label for="s-${k.id}-${s}" class="size-label">${s}</label>
                                    `).join('')}
                                        </div>
                                        
                                        <button class="btn-add-cart" onclick="addToCart(${k.id}, '${k.name.replace(/'/g, "\\'")}', ${k.price}, '${k.img}')">
                                            Add To Cart
                                        </button>
                                    </div>
                                    </div>
                                </div>
                            `).join('')}
                </div>
            </div>
        `).join('');
        }

        function toggleDrawer(id) {
            closeAll();
            const drawer = document.getElementById(`drawer-${id}`);
            const flag = document.getElementById(`flag-${id}`);
            if (drawer) {
                drawer.style.display = 'block';
                flag.classList.add('active');
                drawer.scrollIntoView({
                    behavior: 'smooth',
                    block: 'center'
                });
            }
        }

        function closeAll() {
            document.querySelectorAll('.product-drawer').forEach(d => d.style.display = 'none');
            document.querySelectorAll('.flag-card').forEach(f => f.classList.remove('active'));
        }

        function addToCart(id, name, price, img) {
            const sizeInput = document.querySelector(`input[name="size-${id}"]:checked`);
            if (!sizeInput) return alert("দয়া করে প্রথমে একটি সাইজ (Size) সিলেক্ট করুন!");

            const size = sizeInput.value;
            const existing = cart.find(i => i.id === id && i.size === size);
            existing ? existing.qty++ : cart.push({
                id,
                name,
                price,
                img,
                size,
                qty: 1
            });
            renderCart();
        }

        function renderCart() {
            const list = document.getElementById('cart-list');
            if (!cart.length) {
                list.innerHTML = '<p class="text-center text-muted">Cart is empty</p>';
                return updateTotal();
            }

            list.innerHTML = cart.map((item, idx) => `
            <div class="d-flex align-items-center justify-content-between p-3 mb-2 bg-light rounded-4 border">
                <div class="d-flex align-items-center">
                    <img src="${item.img}" width="50" class="rounded me-3">
                    <div>
                        <div class="fw-bold small">${item.name}</div>
                        <div class="text-muted" style="font-size:12px">Size: ${item.size} | Qty: ${item.qty}</div>
                    </div>
                </div>
                <div class="fw-bold text-dark">${item.price * item.qty} TK</div>
                <button class="btn btn-sm btn-outline-danger" onclick="cart.splice(${idx},1); renderCart()">×</button>
            </div>
        `).join('');
            updateTotal();
        }

        function updateTotal() {
            const sub = cart.reduce((a, b) => a + (b.price * b.qty), 0);
            const delEl = document.querySelector('input[name="area"]:checked');
            const del = delEl ? parseInt(delEl.value) : 0;
            document.getElementById('total-val').innerText = sub + del;
        }

        loadDynamicTeams();
        renderHeroDeals();
        renderFlags();
    </script>


    <script>
        // Listen for the form submission
        document.getElementById('order-form').addEventListener('submit', async function(e) {
            e.preventDefault(); // Stop page from refreshing

            // 1. Validation: Check if cart is empty
            if (cart.length === 0) {
                alert("আপনার কার্ট খালি! দয়া করে পণ্য যোগ করুন। (Cart is empty!)");
                return;
            }

            // 2. Confirmation Check
            const isConfirmed = confirm("আপনি কি অর্ডারটি নিশ্চিত করতে চান? (Confirm your order?)");
            if (!isConfirmed) return;

            // 3. Gather Form Data
            const customerName = this.querySelector('input[name="customer_name"]').value;
            const mobile = this.querySelector('input[name="mobile"]').value;
            const address = this.querySelector('textarea[name="address"]').value;

            const deliveryEl = document.querySelector('input[name="area"]:checked');
            const deliveryType = deliveryEl.id === 'in' ? 'Inside Dhaka' : 'Outside Dhaka';
            const deliveryCharge = parseInt(deliveryEl.value);

            const subtotal = cart.reduce((a, b) => a + (b.price * b.qty), 0);

            // 4. Prepare Payload
            const payload = {
                customer_name: customerName,
                mobile: mobile,
                address: address,
                delivery_type: deliveryType,
                delivery_charge: deliveryCharge,
                cart: cart.map(item => ({
                    product_id: item.id, // item.id from your cart array
                    name: item.name,
                    size: item.size,
                    qty: item.qty,
                    price: item.price
                })),
                subtotal: subtotal,
                total: subtotal + deliveryCharge
            };

            console.log("Submitting Order:", payload);

            // 5. Submit via Fetch
            try {
                const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

                const response = await fetch('/v1/orders', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-CSRF-TOKEN': csrfToken
                    },
                    body: JSON.stringify(payload)
                });

                const data = await response.json();

                if (response.ok && data.success) {
                    alert("ধন্যবাদ! আপনার অর্ডারটি সফলভাবে গ্রহণ করা হয়েছে। (Order placed successfully!)");

                    // Clear cart and UI
                    cart = [];
                    renderCart();
                    this.reset(); // Clear the form

                    // Optional: Redirect to a success page or reload
                    window.location.reload();
                } else {
                    alert("অর্ডার ব্যর্থ হয়েছে: " + (data.message || data.error || 'Server error'));
                }
            } catch (error) {
                console.error("Submission error:", error);
                alert("নেটওয়ার্ক সমস্যা! আবার চেষ্টা করুন। (Network error, please try again.)");
            }
        });
    </script>
</body>

</html>
